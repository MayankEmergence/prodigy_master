# PRODiGY — Artist Management Operating System

A booking enquiry becomes a confirmed show, a signed contract, a raised invoice, a collected payment, a
ledger entry and an artist payout — without leaving the platform or being re-keyed into a spreadsheet.

Three surfaces on one data layer: an **Admin ERP** (20 modules), an **Organizer Portal** (13), and an
**Artist Portal** (12). Plus a public marketing site and a Node/SQLite backend.

---

## Quickest start — with the backend

```bash
cd server
npm install      # builds better-sqlite3 natively, ~1 minute
npm start
```

Open **http://localhost:4000/platform.html**. The badge in the top bar reads **LIVE**. Every write is a real
HTTP call against a real database and survives a refresh. The database seeds itself on first boot.

## Even quicker — without it

Double-click `platform.html`. The badge reads **DEMO** and it runs on a deterministic in-memory seed —
everything works, nothing persists. Useful for a look around; not useful for adding an artist you want to keep.

---

## Files

| File | What it is |
|---|---|
| `platform.html` | The operating system — 45 views across three roles |
| `index.html` | The public marketing site |
| `documentation.html` | PRD, IA, user flows, ER diagram, API reference, design system, deployment, testing |
| `server/` | Node + Express + SQLite backend — see `server/README.md` |

All three HTML files are single-file and self-contained. No build step.

## Sign in

Password is `prodigy` for every account. The three buttons on the sign-in screen use the owner, organizer and
artist accounts; typing real credentials into the form uses those instead.

| Email | Role |
|---|---|
| `aditi.verma@prodigy.agency` | owner — everything |
| `ishita.rao@prodigy.agency` | admin — bookings, roster, contracts, CMS; not payments |
| `rahul.nair@prodigy.agency` | finance — invoices, payments, ledger; not the roster |
| `vikram.shah@prodigy.agency` | sales — pipeline; blocked at the approval gate |
| `marcus@nachtform.de` | organizer — own bookings only, never sees fee floors |
| `kavi@prodigy.agency` | artist — own shows, income and documents only |

## Worth trying

- **⌘K** anywhere — fuzzy search across navigation, all artists, bookings and organizers.
- **Roster → + Sign artist** — add someone. Then delete them. Then try deleting an artist who has bookings and see what the server says instead.
- **Open any booking → Advance stage** — watch the contract and the GST/TDS invoice generate themselves.
- **Sign out, sign back in as `kavi@prodigy.agency`** — the same system, showing only what an artist is allowed to see.

## Tests

```bash
cd server
npm test                  # 90 API tests — auth, RBAC, CRUD, booking engine, tax maths
npm run test:integration  # 51 tests driving the real UI against the real API
npm run test:all
```

141 tests, nothing mocked. The integration suite loads `platform.html` in a headless DOM, signs in against a
live server, renders all 45 views, and puts an artist through create → verify-in-database → edit → delete.

## Shape of it

```
prodigy/
├── platform.html          the OS
├── index.html             public site
├── documentation.html     system documentation
└── server/
    ├── src/
    │   ├── server.js      express, logging, rate limiting, static hosting
    │   ├── routes.js      every endpoint
    │   ├── auth.js        JWT, bcrypt, RBAC scopes, problem+json errors
    │   ├── domain.js      stages + GST/TDS/commission maths — pure functions
    │   ├── db.js          SQLite schema and query helpers
    │   └── seed.js        deterministic seed data
    ├── test/              api.test.js · integration.test.js
    ├── public/            the three HTML files, served from the same origin
    ├── Dockerfile · docker-compose.yml
    └── README.md          full API reference
```

## Known integration points

Payments and e-signature run through to confirmation and the ledger, but Razorpay, Stripe and DocuSign are
stubs at the boundary. Document metadata and version history are real; S3 presigned upload is not wired.
The AI assistant answers from live database queries rather than a model call — the figures it quotes are
real, and swapping in a streaming LLM endpoint touches one function.
